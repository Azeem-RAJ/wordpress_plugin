    <div class="wrap">
        <h1>connections</h1>
        <p>Integration settings and options go here.</p>
    </div>
